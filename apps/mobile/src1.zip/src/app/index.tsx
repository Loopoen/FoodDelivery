
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  Text,
  View,
} from 'react-native';
import { Redirect, useRouter } from 'expo-router';
import * as SecureStore from 'expo-secure-store';

type AuthStatus = 'loading' | 'authed' | 'guest';

export default function Index() {
  const router = useRouter();

  const [status, setStatus] = useState<AuthStatus>('loading');
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // Kiểm tra token khi mở trang
  useEffect(() => {
    let isMounted = true;

    const checkAuth = async () => {
      try {
        const token = await SecureStore.getItemAsync('token');

        if (isMounted) {
          setStatus(token ? 'authed' : 'guest');
        }
      } catch (error) {
        console.error('Lỗi kiểm tra đăng nhập:', error);

        if (isMounted) {
          setStatus('guest');
        }
      }
    };

    checkAuth();

    return () => {
      isMounted = false;
    };
  }, []);

  // Đăng xuất
  const onLogout = async () => {
    if (isLoggingOut) return;

    setIsLoggingOut(true);

    try {
      await SecureStore.deleteItemAsync('token');

      setStatus('guest');
      router.replace('/login');
    } catch (error) {
      console.error('Lỗi đăng xuất:', error);

      Alert.alert(
        'Lỗi',
        'Không thể đăng xuất. Vui lòng thử lại.',
      );

      setIsLoggingOut(false);
    }
  };

  // Đang kiểm tra token
  if (status === 'loading') {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: '#fff',
        }}
      >
        <ActivityIndicator size="large" color="#DC3535" />
        <Text style={{ marginTop: 12, color: '#666' }}>
          Đang kiểm tra đăng nhập...
        </Text>
      </View>
    );
  }

  // Chưa đăng nhập
  if (status === 'guest') {
    return <Redirect href="/login" />;
  }

  // Đã đăng nhập
  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 24,
        backgroundColor: '#fff',
      }}
    >
      <Text
        style={{
          fontSize: 28,
          fontWeight: '700',
          marginBottom: 10,
          color: '#DC3535',
        }}
      >
        Food Delivery
      </Text>

      <Text
        style={{
          fontSize: 18,
          color: '#666',
          marginBottom: 30,
          textAlign: 'center',
        }}
      >
        Chào mừng bạn đến trang chính
      </Text>

      <Pressable
        onPress={onLogout}
        disabled={isLoggingOut}
        style={{
          backgroundColor: '#DC3535',
          paddingHorizontal: 24,
          paddingVertical: 12,
          borderRadius: 10,
          opacity: isLoggingOut ? 0.6 : 1,
        }}
      >
        {isLoggingOut ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text
            style={{
              color: '#fff',
              fontWeight: '600',
              fontSize: 16,
            }}
          >
            Đăng xuất
          </Text>
        )}
      </Pressable>
    </View>
  );
}
