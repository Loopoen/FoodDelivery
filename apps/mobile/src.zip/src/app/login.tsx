import { useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useRouter } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import * as SecureStore from 'expo-secure-store';

WebBrowser.maybeCompleteAuthSession();

type UserRole = 'CUSTOMER' | 'RESTAURANT_OWNER' | 'DRIVER';
type Mode = 'login' | 'register';

const API = process.env.EXPO_PUBLIC_API_URL;

const ROLES: { value: UserRole; label: string }[] = [
  { value: 'CUSTOMER', label: '👤 Khách hàng' },
  { value: 'RESTAURANT_OWNER', label: '🍔 Chủ nhà hàng' },
  { value: 'DRIVER', label: '🛵 Tài xế' },
];

async function postJson(path: string, body: unknown) {
  const res = await fetch(`${API}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = Array.isArray(data?.message) ? data.message.join('\n') : data?.message;
    throw new Error(msg ?? 'Có lỗi xảy ra, vui lòng thử lại');
  }
  return data;
}

const inputStyle = {
  borderWidth: 1,
  borderColor: '#ddd',
  borderRadius: 12,
  paddingHorizontal: 14,
  paddingVertical: 12,
  fontSize: 16,
  marginBottom: 12,
} as const;

export default function LoginScreen() {
  const router = useRouter();

  const [mode, setMode] = useState<Mode>('login');
  const [role, setRole] = useState<UserRole>('CUSTOMER');
  const [loading, setLoading] = useState(false);

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const saveTokenAndGoHome = async (token: unknown) => {
    if (typeof token !== 'string') throw new Error('Không nhận được token');
    await SecureStore.setItemAsync('token', token);
    router.replace('/');
  };

  // Đăng nhập / đăng ký bằng email + mật khẩu
  const onSubmit = async () => {
    try {
      if (!email.trim() || !password) {
        throw new Error('Vui lòng nhập email và mật khẩu');
      }
      if (mode === 'register' && (!firstName.trim() || !lastName.trim())) {
        throw new Error('Vui lòng nhập họ và tên');
      }

      setLoading(true);

      const data =
        mode === 'login'
          ? await postJson('/auth/login', {
              email: email.trim().toLowerCase(),
              password,
            })
          : await postJson('/auth/register', {
              firstName: firstName.trim(),
              lastName: lastName.trim(),
              email: email.trim().toLowerCase(),
              password,
              role,
            });

      await saveTokenAndGoHome(data.token);
    } catch (e: any) {
      Alert.alert('Lỗi', e.message);
    } finally {
      setLoading(false);
    }
  };

  // Đăng nhập Google (Expo Go, qua backend trung gian)
  const onGooglePress = async () => {
    try {
      setLoading(true);

      const returnUrl = Linking.createURL('login');
      const startUrl =
        `${API}/auth/google/start` +
        `?role=${role}` +
        `&returnUrl=${encodeURIComponent(returnUrl)}`;

      const result = await WebBrowser.openAuthSessionAsync(startUrl, returnUrl);
      if (result.type !== 'success') return;

      await saveTokenAndGoHome(Linking.parse(result.url).queryParams?.token);
    } catch (e: any) {
      Alert.alert('Lỗi', e.message);
    } finally {
      setLoading(false);
    }
  };

  const isRegister = mode === 'register';

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: '#fff' }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24 }}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={{ fontSize: 28, fontWeight: '700', textAlign: 'center', marginBottom: 8 }}>
          Food Delivery
        </Text>
        <Text style={{ textAlign: 'center', color: '#666', marginBottom: 24 }}>
          {isRegister ? 'Tạo tài khoản mới' : 'Đăng nhập để tiếp tục'}
        </Text>

        {/* Chọn vai trò (dùng cho đăng ký và Google) */}
        <View style={{ marginBottom: 12 }}>
          {ROLES.map((r) => (
            <Pressable
              key={r.value}
              onPress={() => setRole(r.value)}
              style={{
                padding: 14,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: role === r.value ? '#DC3535' : '#ddd',
                marginBottom: 10,
              }}
            >
              <Text style={{ textAlign: 'center', fontWeight: '600' }}>{r.label}</Text>
            </Pressable>
          ))}
        </View>

        {isRegister && (
          <>
            <TextInput
              style={inputStyle}
              placeholder="Họ"
              value={lastName}
              onChangeText={setLastName}
            />
            <TextInput
              style={inputStyle}
              placeholder="Tên"
              value={firstName}
              onChangeText={setFirstName}
            />
          </>
        )}

        <TextInput
          style={inputStyle}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
        />
        <TextInput
          style={inputStyle}
          placeholder="Mật khẩu"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          autoCapitalize="none"
        />

        <Pressable
          onPress={onSubmit}
          disabled={loading}
          style={{
            paddingVertical: 14,
            borderRadius: 12,
            backgroundColor: '#DC3535',
            alignItems: 'center',
            opacity: loading ? 0.6 : 1,
          }}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#fff' }}>
              {isRegister ? 'Đăng ký' : 'Đăng nhập'}
            </Text>
          )}
        </Pressable>

        <Pressable
          onPress={() => setMode(isRegister ? 'login' : 'register')}
          disabled={loading}
          style={{ paddingVertical: 14 }}
        >
          <Text style={{ textAlign: 'center', color: '#DC3535', fontWeight: '600' }}>
            {isRegister ? 'Đã có tài khoản? Đăng nhập' : 'Chưa có tài khoản? Đăng ký'}
          </Text>
        </Pressable>

        <View style={{ flexDirection: 'row', alignItems: 'center', marginVertical: 8 }}>
          <View style={{ flex: 1, height: 1, backgroundColor: '#eee' }} />
          <Text style={{ marginHorizontal: 12, color: '#999' }}>hoặc</Text>
          <View style={{ flex: 1, height: 1, backgroundColor: '#eee' }} />
        </View>

        <Pressable
          onPress={onGooglePress}
          disabled={loading}
          style={{
            marginTop: 12,
            paddingVertical: 14,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: '#ddd',
            alignItems: 'center',
            opacity: loading ? 0.6 : 1,
          }}
        >
          <Text style={{ fontSize: 16, fontWeight: '600' }}>Tiếp tục với Google</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}