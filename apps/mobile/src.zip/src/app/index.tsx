import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  Text,
  View,
} from 'react-native';
import { Redirect, useRouter } from 'expo-router';
import * as SecureStore from 'expo-secure-store';

export default function Index() {
  const router = useRouter();

  const [status, setStatus] = useState<
    'loading' | 'authed' | 'guest'
  >('loading');

  useEffect(() => {
    const checkAuth = async () => {
      const token = await SecureStore.getItemAsync('token');

      setStatus(token ? 'authed' : 'guest');
    };

    checkAuth();
  }, []);

  // Đang kiểm tra token
  if (status === 'loading') {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <ActivityIndicator size="large" />
      </View>
    );
  }

  // Chưa đăng nhập
  if (status === 'guest') {
    return <Redirect href="/login" />;
  }

  // Đã đăng nhập → Trang chính
  const onLogout = async () => {
    await SecureStore.deleteItemAsync('token');

    router.replace('/login');
  };

  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
      }}
    >
      <Text
        style={{
          fontSize: 28,
          fontWeight: '700',
          marginBottom: 10,
        }}
      >
        Food Delivery
      </Text>

      <Text
        style={{
          fontSize: 18,
          color: '#666',
          marginBottom: 30,
        }}
      >
        Chào mừng bạn đến trang chính
      </Text>

      <Pressable
        onPress={onLogout}
        style={{
          backgroundColor: '#e11d48',
          paddingHorizontal: 24,
          paddingVertical: 12,
          borderRadius: 10,
        }}
      >
        <Text
          style={{
            color: '#fff',
            fontWeight: '600',
          }}
        >
          Đăng xuất
        </Text>
      </Pressable>
    </View>
  );
}